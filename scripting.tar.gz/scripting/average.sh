#!/bin/sh

#initialize average and total sum
avg=0
total=0
number_of_args=$#

# Check if enough arguments given 
if [ $# -lt 2 ] ; then
   echo -e "I need atleast 2 command line args\n"
   echo -e "Syntax: $0: number1 number2 ... numberN\n"
   break
fi

#calculate the average of numbers given on command line as cmd args
for i in $*
 do
   #total sum of all the numbers 
   total=`expr $total + $i `
 done

#calculate average from total sum and number_of_args
avg=`expr $total / $number_of_args `     
echo "Average value of the numbers is $avg"

