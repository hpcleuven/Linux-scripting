#!/bin/bash
echo "Which Operating System do you like?"
select os in Ubuntu CentOS Windows10 Windows11 
do

case $os in
# Two case values are declared here for matching
"Ubuntu"|"CentOS")
echo "I also use $os."
;;
# Three case values are declared here for matching
"Windows11" | "Windows10")
echo "Why don't you try Linux?"
;;
# Matching with invalid data
*)
echo "Invalid entry."
break
;;
esac
done
