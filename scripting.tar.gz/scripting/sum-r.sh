#!/bin/sh

#!/bin/sh

if [ $# -ne 2 ]
then
   echo "Usage - $0   x    y"
   echo "Where x and y are two real numbers to add"
#scale is not necessary - these numbers are already real, so bc will adjust
else
  x=$1
  y=$2
  z=`echo "$1+$2"| bc`
  echo "$x + $y = $z"
fi

