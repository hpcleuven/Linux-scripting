#!/bin/bash

for myVar in $*

do
  echo $myVar
done

