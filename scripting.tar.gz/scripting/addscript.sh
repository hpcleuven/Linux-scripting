#!/bin/bash
expr $1 + $2

