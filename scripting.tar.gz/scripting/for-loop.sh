#!/bin/bash
for var
do
  echo $var
done

