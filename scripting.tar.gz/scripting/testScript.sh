#!/bin/bash

echo "The name of the program is: $0"
echo "The first parameter is: $1"
echo "There are $# parameters"
echo "All of the parameters are: $*"
echo "${10}"
echo $11

