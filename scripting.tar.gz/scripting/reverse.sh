#!/bin/sh

# condition to inform user how the script should be running 
#e.g. too many parameters, etc.
if [ $# -ne 1 ]
then
    echo "Execute: $0   number"
    echo "         Script will find reverse of given positive integer"
    echo "         For eg. $0 123, it will print 321"
    exit 1
fi

number=$1
#initialize reversed number and 
rev=0

while [ $number -gt 0 ]
do
rev=`expr $rev \* 10 + $number % 10`
number=`expr $number / 10`
#if you wish to follow intermediate steps, you can print it the loop 
#e.g. uncomment next line
#echo $rev $number
done
echo  "Reverse number is $rev"

