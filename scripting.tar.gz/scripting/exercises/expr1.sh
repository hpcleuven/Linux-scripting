#!/bin/bash
i=$1
echo "Initial value is: $i"
echo -n "Value after adding is "
echo "$i+2"|bc
echo -n "Value after multiplying is "
echo "($i+2)*3"|bc
echo -n "Value after performing modulo is "
echo "($i+2)*3%2"|bc


