#!/bin/bash
#check if all the arguments are provided: 2 numbers and operation
if test $# = 3
then
        case $2 in
         #sum
         +) let result=$1+$3;;
         #subtract
         -) let result=$1-$3;;
         #multiply
         #case insensitive
         x|X) let result=$1*$3;;
         #divide
         /) let result=$1/$3;;
         #unknown operator
         *) echo Warning - $2 invalid operator, only +,-,x,/ operator allowed
            exit;;
        esac
        echo $1 $2 $3 = $result
else
        echo "Syntax: $0   value1  operator value2"
        echo "where, value1 and value2 are numeric values"
        echo "operator can be +,-,x,/"
fi

