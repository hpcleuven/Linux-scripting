#!/bin/bash
i=$1
echo "Initial value is: $i"
i=`expr $i + 2`
echo "Value after adding is $i"
i=`expr $i \* 3`
echo "Value after multiplying is $i"
i=`expr $i % 2`
echo "Value after performing modulo is $i"


