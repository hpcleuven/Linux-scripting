#!/bin/bash
if [ $# -ne 5 ]
then
    echo "Usage: $0   num1 num2 num3 num4 num5"
    echo "Numbers will be sorted"
    exit 1
fi
# Declare the array of 5 subscripts to hold 5 numbers
numbers=($1 $2 $3 $4 $5)
# Print the number before sorting process
echo "Original (not yet sorted) numbers in array:"
for (( i = 0; i <= 4; i++ ))
do
  echo ${numbers[$i]}
done
#Sort the numbers
for (( i = 0; i <= 4 ; i++ ))
do
#iterate all the numbers for comparison for each number
#make sure that numbers already sorted are not taken any more
   for (( j = $i; j <= 4; j++ ))
   do
#substitute current number by the smallest number left
#(number not considered before)
      if [ ${numbers[$i]} -gt ${numbers[$j]}  ]; then
           temp=${numbers[$i]}
           numbers[$i]=${numbers[$j]}
           numbers[$j]=$temp
      fi
   done
done
# Print the sorted numbers
echo -e "\nSorted numbers (ascending order):"
for (( i=0; i <= 4; i++ ))
do
  echo ${numbers[$i]}
done



