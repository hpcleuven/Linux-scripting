#!/bin/bash

#Before noon
function bn {
if [ $hour -lt 12 -a $hour -ge 6 ]
then
    echo "Good Morning $USER, Have nice day!"
fi
}

#between noon and 4pm
function bna4 {
if [ $hour -gt 12 -a $hour -le 16 ]
then
     echo "Good Afternoon $USER"
fi
}

#from 4pm till 10 pm

function f4t10 {
if [ $hour -gt 16 -a $hour -le 22 ]
then
     echo "Good Evening $USER "
fi
}

#from 10pm on
function f10o {
if [ $hour -gt 22 -o $hour -lt 6 ]
then
    echo "You should be sleeping now. Good Night!"
fi
}


#from the date command
#take the information about time (and precisely about the hour)
#which is stored in field 12 and 13
hour=`date | cut -c12-13`

#provide date in some nice format
dat=`date +"%A %d in %B of %Y (%r)"`

bn $hour
bna4 $hour
f4t10 $hour
f10o $hour

echo -e "This is $dat"




