#!/bin/bash
echo "Hello $USER!"