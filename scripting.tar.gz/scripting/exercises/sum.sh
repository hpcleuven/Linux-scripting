#!/bin/bash
#check if number of arguments is 2, if not - print warning, if yes - proceed
if [ $# -ne 2 ]
then
   echo "Execution: $0   x    y"
   echo "Where x and y are two integers for which sum will be calculated"
else
   sum=`expr $1 + $2 `
   echo "Sum of $1 and $2 is $sum "
fi

