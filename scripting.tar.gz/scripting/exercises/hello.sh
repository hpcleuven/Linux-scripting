#!/bin/bash
echo "Hello Mag!"

