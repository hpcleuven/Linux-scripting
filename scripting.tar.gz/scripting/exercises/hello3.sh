#!/bin/bash
echo "Hello $USER!"
echo "Your input is: $1"
