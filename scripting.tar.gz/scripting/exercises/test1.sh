#!/bin/bash
i=$1
j=$2
echo "Values to test $i $j"
test $i -gt $j && echo "True"
test $i -gt $j || echo "False"


