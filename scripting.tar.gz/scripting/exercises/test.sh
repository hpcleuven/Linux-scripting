#!/bin/bash
i=$1
j=$2
echo "Values to test $i $j"
test $i -ge $j
k=$?
echo "Test exitcode is $k"


