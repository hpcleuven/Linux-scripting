#!/bin/bash
echo "Hello Mag"
echo "Today is `$today`"
