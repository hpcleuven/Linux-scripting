#!/bin/bash
if [ ! -x $1 ] ; then
   cat $1
fi

