#!/bin/bash
set -e
set -x
echo "hello"
echo $?
grep not_there /dev/null
echo $?
