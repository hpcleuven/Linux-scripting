#!/bin/bash

counter=0

while [ $counter -lt 10 ] 

do
  
  echo first $counter
  counter=`expr $counter + 1`
  echo again $counter

done


