#!/bin/bash

counter=0

until [ $counter -eq 10 ] 

do
  
  echo before $counter
  counter=`expr $counter + 1`
  echo after $counter

done


