#!/bin/bash

case $1 in

*.sh)
   echo "Shell Script" ;;

*.txt)
   echo "Text file" ;;

*)
   echo "Some other file" ;;

esac

