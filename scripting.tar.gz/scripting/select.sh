#!/bin/bash
# Define the menu list here
select cluster in Genius wICE Superdome BrEniac Hortense
do
echo "You have chosen $cluster"
break
done

