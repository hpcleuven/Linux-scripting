#!/bin/bash
if [ ! -x $1 ] ; then
   cat $1
else
   echo "Executable file: not printing $1"
fi

