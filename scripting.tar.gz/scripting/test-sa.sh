#!/bin/sh

while [ 1 ]

do
   echo "Wakeup [yes/no]?"
   read resp
   
   if [ $resp = "yes" ]
   then
      break
   fi

done

