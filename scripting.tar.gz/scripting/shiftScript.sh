#!/bin/bash

echo "Parameter 1 before shift: $1"
shift
echo "Parameter 1 after shift: $1"

