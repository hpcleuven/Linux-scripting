#!/bin/sh

#factorial n! is the product of all positive integers less than or equal to n. 
#For example 5 ! = 5 × 4 × 3 × 2 × 1 = 120.

#initialize factorial and the number
n=0; rn=0
fact=1 
echo -n "Enter number to find factorial : "
read n

#remember the value of read number
rn=$n
#iterate over every number starting from $n
while [ $n -ge  1 ]
do
  fact=`expr $fact \* $n`
  n=`expr $n - 1`
done
echo "$rn! = $fact"

