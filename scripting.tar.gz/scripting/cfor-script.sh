#!/bin/bash

LIMIT=10
for (( a=1; a<=LIMIT; a++))

do
  echo "$a"
done

