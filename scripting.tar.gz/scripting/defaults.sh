#!/bin/bash
FIRST_ARG="${1:-no_first_arg}"
SECOND_ARG="${2:-no_second_arg}"
THIRD_ARG="${3:-no_third_arg}"
#FOURTH_ARG="${4:=defaultval}"
echo ${FIRST_ARG}
echo ${SECOND_ARG}
echo ${THIRD_ARG}
#echo ${FOURTH_ARG}
